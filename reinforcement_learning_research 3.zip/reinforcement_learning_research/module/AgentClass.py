import module.MazeQ_Run as Run
import numpy as np

class QLearningAgent(Run.AgentParameters):
    def __init__(self,maze_w_size, gamma, alpha, epsilon, pi, qvc):
        super().__init__(maze_w_size, gamma, alpha, epsilon, pi, qvc)
        # self.maze_w_size = maze_w_size
        # self.gamma = gamma
        # self.alpha = alpha
        # self.epsilon = epsilon
        # self.pi = pi
        # self.qvc = qvc

        # self.random_pi = [[j for j,x in enumerate(i) if np.isnan(x) == False] for i in self.pi] #piからある状態sの時に、行動可能方向の添字を配列に格納する処理をしている (例：[nan,1,1,nan] → [1,2])
        # self.Q  = [] #インスタンス直後は空配列　→ make_Q_table実装後２次元配列のQテーブルが格納される

    #Qテーブル作成メソッド
    def make_Q_table(self):
        [a, b] = self.pi.shape
        # self.Q = np.random.rand(a, b) * self.pi * self.alpha
        Q = np.random.rand(a, b) * self.pi * self.alpha
        self.Q = [[ x for j,x in enumerate(i) if np.isnan(x) == False] for i in Q]
        
    
    #単純に割合計算するメソッド
    def simple_convert_into_pi_from_theta(self):
        [m, n] = self.pi.shape
        new_pi = np.zeros((m, n))
        for i in range(0,m):
            new_pi[i, :] = self.pi[i, :] / np.nansum(self.pi[i,:])
            new_pi = np.nan_to_num(new_pi)
        self.pi = new_pi
    
    #方策規格の状態を標準の状態へ変換するメソッド
    def condition_standard_converter(self,maze_name, state):
        # MN = 0 if maze_name == "A" or maze_name == "C" or maze_name == "main_maze" else 1
        if maze_name == "A" or maze_name == "C":
            MN = 0
        elif maze_name == "B" or maze_name == "D" or maze_name == "main_maze":
            MN = 1
        if maze_name == "main_maze":
            h = int(state // self.maze_w_size)
            w = int(self.qvc[h].index(state))
            return list([h+1,w+1]), list([h,w]) # list([h+1,w+1])
        
        h = int(state//self.maze_w_size)
        w = int(self.qvc[MN][h].index(state))
        return list([h+1,w+1]), list([h,w]) # list([h+1,w+1])
    
    #行動選択(方策：ε-greedy)
    def epsilon_greedy_policy(self, state, gate_name):
        if type(state) is list:
            state = int(state[0])
        random_a = [0,1,2,3]
        # print(f"rondom_pi: {self.random_pi[state]}")
        if np.random.rand() < self.epsilon:
            # next_direction = np.random.choice(random_a, p=self.pi[state,:])
            next_direction = np.random.choice(self.random_pi[state])
            
        else:
            # next_direction = random_a[np.nanargmax(self.Q[state,:])]
            # next_direction = self.random_pi[state][self.Q[state].index(np.nanargmax(self.Q[state,:]))]
            # next_direction = self.random_pi[state][np.nanargmax(self.Q[state])]
            next_direction = self.random_pi[state][np.nanargmax(self.Q_table_list[gate_name][state])]
        return next_direction
    
    #Qテーブル更新するメソッド
    def update_Q(self, state, next_s, action, reward, done, gate_name):
        print(f"action:{action}, state:{state},n_state:{next_s}")
        action = self.random_pi[state].index(action)
        next_q_max = 0 if done else self.Q[next_s][np.nanargmax([i for i in self.Q[next_s]])]
        target = self.gamma * next_q_max + reward
        # self.Q[state][action] += (target - self.Q[state][action]) * self.alpha
        self.Q_table_list[gate_name][state][action] += (target -self.Q_table_list[gate_name][state][action]) * self.alpha

        



if __name__ == '__main__':
    print("これは自作モジュールです")
    print("This module is self-made")