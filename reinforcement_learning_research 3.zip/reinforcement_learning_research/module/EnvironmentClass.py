import copy
import numpy as np
import module.MazeQ_Run as Run

class MazeEnvironment(Run.EnvParameters):
    def __init__(self, name, gate, maze, start, original_state_positon, qvc):
        super().__init__(name, gate, maze, start, original_state_positon, qvc)

        # self.name = name
        # self.gate = gate
        # self.maze = maze
        # self.update_maze = copy.deepcopy(maze)
        # self.start = start
        # self.osp = original_state_positon
        # self.qvc = qvc
        # self.past = []
        

        if original_state_positon != "_":
            self.maze[self.osp[0]][self.osp[1]] = 9

    #迷路可視化メソッド
    def maze_print(self, maze):
        for i in maze:
            for n in i:
                if n == 1:
                    print(" ■",end="") # colabで動かす時は図形の前に空白はいらない
                elif n == 0:
                    print("  ",end="") #colabで動かすときは空欄ではなく”空”を入れる
                elif n == 3:
                    print(" S",end="")
                elif n == 4 or n == 9:
                    print(" G",end="")
                elif n == 6:
                    print(" △",end="")
                elif n == 7 or n == 9:
                    print("門",end="")
                elif n >= 8:
                    print(f" {str(n-7)}",end="")
                    # print(" T",end="")
                elif n == 2:
                    print(" ▲",end="")
                else:
                    print("他",end="")
            print()
     

    #迷路のリセット・スタート割り当てメソッド
    def maze_reset(self,start_0):
        maze_copy = copy.deepcopy(self.maze)
        
        if self.osp != "_":
            maze_copy[self.osp[0]][self.osp[1]] = 4
            self.update_maze[self.osp[0]][self.osp[1]] = 4

        if type(start_0) is list:
            h, w = start_0
            maze_copy[h][w] = 3
            self.update_maze[h][w] = 3
        else:
            maze_copy[self.gate[start_0][0]][self.gate[start_0][1]] = 3
            self.update_maze[self.gate[start_0][0]][self.gate[start_0][1]] = 3

        self.maze_print(self.update_maze)
        return maze_copy
    
    # 移動状況の可視化をするメソッド
    def update(self, destination, n): #destination　→　next_s or ns
        if self.update_maze[destination[0]][destination[1]] != 4:
            h, w = self.Maze_gate_start if n == 0 else self.start # self.start
            dh, dw = destination

            if self.past != []:
                ph,pw = self.past
                self.update_maze[ph][pw] = 6

            self.update_maze[dh][dw] = 2
            self.update_maze[h][w] = 3
            self.past = destination
            self.maze_print(self.update_maze)

        # self.maze_print(maze)

    
    def next_state(self, state, action):
        h,w = state
        # h -= 1
        # w -= 1
        dier = [(-1,0), (0,1), (1,0), (0,-1)]
        if self.name == "main_maze":
            qvc_state = int(self.qvc[h][w])
            maze_w = len(self.maze[0]) 

        elif self.name == "B" or self.name == "D":
            qvc_state = int(self.qvc[1][h][w])
            maze_w = len(self.maze[0]) -1
            
        elif self.name == "A" or self.name == "c":
            qvc_state = int(self.qvc[0][h][w])
            maze_w = len(self.maze[0]) -1
        #上、右、下、左

        move_map = [qvc_state - maze_w, qvc_state+1, qvc_state + maze_w, qvc_state-1]
        next_state_theta = move_map[action]
        next_state = h + dier[action][0], w + dier[action][1]   
        maze_next_state = [i + 1 for i in next_state]
        return next_state_theta, maze_next_state, list(next_state)

    def reward_function(self, next_state):
        h,w = next_state
        if self.update_maze[h][w] == 4 or self.update_maze[h][w] == 9:
            reward = 1000
        else:
            reward = 0
        return reward

    def reward_manhattan_function(self, next_state):
        h,w = next_state
        gh,gw = self.osp
        
        if self.update_maze[h][w] == 4 or self.update_maze[h][w] == 9:
            reward = 10000
            return reward
        else:
            reward = 5000
            y = abs(h - gh)
            x = abs(w - gw)
            manhattan_distance = x + y #マンハッタン距離を計算
            manhattan_reward = reward // manhattan_distance #マンハッタン距離に応じて持分報酬から割り引く
            return manhattan_reward
    
    def reward_manhattan_dead_end_function(self, next_state):
        h, w = next_state
        w_max = len(self.maze[0]) -1
        h_max = len(self.maze) -1
        dier = [(1, 0), (0, 1), (-1, 0), (0, -1)]
        copy_maze = self.maze[h][w]
        x = [[dh+h, dw+w] for dh, dw in dier]
        count_nan = 0
        for h,w in x:
            if w == 0 or h == 0 or w == w_max or h == h_max:
                count_nan += 1
        if count_nan >= 3:
            return -100
        else:
            return self.reward_manhattan_function(next_state) 
           
            

        
        

    def goal_judgment(self, next_state):
        h,w = next_state
        # if self.update_maze[h][w] == 4 or self.update_maze[h][w] == 9:
        #     done = True
        # else:
        #     done = False
        if h == self.osp[0] and w == self.osp[1]:
            done = True
        else:
            done = False
            
        return done
    
if __name__ == '__main__':
    print("これは自作モジュールです")
    print("This module is self-made")   