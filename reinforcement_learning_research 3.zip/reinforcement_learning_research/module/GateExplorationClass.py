import copy
import os
import sys
import traceback

'''
探索優先設定
direc A
<-----優先度が高い
   左 ・  上 ・  下 ・  右
[(0,-1),(-1,0),(1,0),(0,1)]  テスト１ 回数５
   左 ・  上 ・  右 ・  下
[(0,-1),(-1,0),(0,1),(1,0)]  テスト１ 回数５
   上 ・  左 ・  下 ・  右
[(-1,0),(0,-1),(1,0),(0,1)]  テスト２ 回数6
   上 ・  左 ・  右 ・  した
[(-1,0),(0,-1),(0,1),(1,0)]  テスト３ 回数6

'''

class Make_DFS:
    def __init__(self,maze,gate,name):
        self.direc = [(0,-1),(-1,0),(0,1),(1,0)]   if name == "A" else [(0,1),(1,0),(-1,0),(0,-1)]
        self.name = name
        self.default_maze = maze
        self.maze = copy.deepcopy(self.default_maze)
        self.field = 0
        self.gate = copy.deepcopy(gate)
        self.flag = False
        self.rond = []
        self.formal_gate = []
        self.rond_history = []
        self.copy_gate = copy.deepcopy(gate)
        self.H = len(maze)
        self.W = len(maze[0])
        self.s_idx = 0
        self.ss_idx = 0
        self.count = 1
        self.not_rond = []
        self.formal_gate = []

    def maze_print(self, maze_x):
        for i in maze_x:
            for n in i:
                if n == 1:
                    print(" ■",end="") # colabで動かす時は図形の前に空白はいらない
                elif n == 0:
                    print("  ",end="") #colabで動かすときは空欄ではなく”空”を入れる
                elif n == 3:
                    print(" S",end="")
                elif n == 4:
                    print(" G",end="")
                elif n == 6:
                    print(" △",end="")#colabで動かす時は" 済"を入れる
                elif n == 7:
                    print("門",end="")
                elif n >= 8:
                    print(f" {str(n-7)}",end="")
                    # print(" T",end="")
                else:
                    print("他",end="")
            print()

    def maze_temporary_reflection(self,g):
        for i in range(len(self.maze)):
            for j in range(len(self.maze[0])):
                if self.maze[i][j] == 7:
                    self.maze[i][j] == 0
                    break

        self.maze[g[0]][g[1]] = 7
        return self.maze

    def start_search(self):
        for i in range(len(self.maze)):
            for j in range(len(self.maze[0])):
                if self.maze[i][j] == 7:
                    self.s_idx = (i,j)
        return self.s_idx
        

    def dfs(self, h, w):
        if self.flag == False:
            self.flag = False
        elif self.flag == True:
            self.flag = True
        
        self.field[h][w] = 6
        self.rond.append([h,w])

        self.maze_print(self.field)
        print()

        for d in self.direc:
            next_h = h+d[0]
            next_w = w+d[1]
            if next_h >= self.H or next_w >= self.W:
                continue
            if next_h < 0 or next_w < 0:
                continue
            
            next_point = self.field[next_h][next_w]
            if ([h,w] in self.rond_history) == True and self.rond_history != []:
                self.flag = True
                print("Yes 途中経路",self.flag,f"{next_point} ss_idx: {self.ss_idx}")
                #exit()
            if next_point == 1:
                continue
            if next_point == 6:
                continue
            if next_point == 4 or next_point == 3:
                self.flag = True
                print("Yes",self.flag,f"{next_point} ss_idx: {self.ss_idx}")
                #exit()
 

            print(self.flag)
            self.field[h][w] = 6
            if self.flag == True:
                return 
            self.dfs(next_h, next_w)
        self.field[h][w] = 6
    
    def search(self):
        print(f"search: gate = {self.gate}")
        # H = len(maze)
        # W = len(maze[0])
        self.s_idx = self.start_search()
        print(self.s_idx)
        self.ss_idx = [self.s_idx[0], self.s_idx[1]]
        self.not_rond = []
        # self.formal_gate = []

        self.dfs(self.s_idx[0], self.s_idx[1])
        if self.flag == False:
            print("No")
            self.maze[self.ss_idx[0]][self.ss_idx[1]] = 0
            self.rond = []
        
        for i in self.gate:
            if (i in self.rond) == False and self.flag == False:
                pass
            elif (i in self.rond) == False or self.rond == []:
                self.not_rond.append(i)
                print(self.not_rond)
                print(f"search: {i} False")
        
            elif (i in self.rond) == True:
                print(f"search: {i} True")
                self.formal_gate.append(i) 

        return self.not_rond, self.formal_gate, self.rond


    def main(self):
        n = -1 if self.name == "A" else 0
        self.rond = []
        self.maze = []
        self.flag = False
        self.maze = copy.deepcopy(self.default_maze)
        self.field = self.maze_temporary_reflection(self.gate[n])
        self.gate, FX_gate, X_now_rond = self.search()
        formal_gate = []

        print(f"{self.name} FX_gate {self.gate} X_now_rond {X_now_rond}")
        print(f"メインから判定: {self.flag}")
        print(self.count)
        if self.gate != []:
            print(f"{self.name} {self.gate[-1]} {FX_gate}")
            [formal_gate.append(i) for i in FX_gate]# <---- 改善点
            # self.formal_gate.append(formal_gate)#　<----　改善点　
            # self.formal_gate.append(FX_gate)
            print(f"formal_gate = w{formal_gate} self = {self.formal_gate}")
        if self.flag == True and self.gate == []:
            print(f"FX_gate {FX_gate}")
            # self.formal_gate.append(FX_gate)
            [formal_gate.append(i) for i in FX_gate]

        if self.flag == True:
            print(X_now_rond)
            
            [self.rond_history.append(i) for i in (list(map(list, set(map(tuple, X_now_rond)))))]
            self.rond_history = list(map(list, set(map(tuple, self.rond_history))))

        print("_"*100)
        self.count += 1
        if self.gate == []:
            print("f",self.formal_gate)
            return 
        else:
            self.main()

    def start_main(self):
        print(self.gate)
        self.main()
        print(self.formal_gate)
        print(f"探索回数: {self.count}回 {self.gate}")
        self.rond_history = list(map(list, set(map(tuple, self.rond_history))))
        print("end",sorted(self.rond_history))
        print(type(self.formal_gate))
        return  list(self.formal_gate)
        #yield self.formal_gate
        
if __name__ == '__main__':
    print("これは自作モジュールです")
    