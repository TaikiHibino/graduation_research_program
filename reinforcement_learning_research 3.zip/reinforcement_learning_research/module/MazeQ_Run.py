# import module.AgentClass as Agent
# import module.EnvironmentClass as Env_Class
import copy
import numpy as np


class EnvParameters:
    def __init__(self, name, gate, maze, start, original_state_positon, qvc):
        print("パラメータ初期化")
        self.name = name
        self.gate = gate
        self.maze = maze
        self.update_maze = copy.deepcopy(maze)
        self.start = start
        self.osp = original_state_positon
        self.qvc = qvc
        self.past = []
        self.Maze_gate_start = []

class AgentParameters:
    def __init__(self,maze_w_size, gamma, alpha, epsilon, pi, qvc):
        self.maze_w_size = maze_w_size
        self.gamma = gamma
        self.alpha = alpha
        self.epsilon = epsilon
        self.pi = pi
        self.qvc = qvc

        self.random_pi = [[j for j,x in enumerate(i) if np.isnan(x) == False] for i in self.pi] #piからある状態sの時に、行動可能方向の添字を配列に格納する処理をしている (例：[nan,1,1,nan] → [1,2])
        self.Q  = [] #インスタンス直後は空配列　→ make_Q_table実装後２次元配列のQテーブルが格納される
        self.Q_table_list = {}


class testRun(AgentParameters, EnvParameters):
    def __init__(self, maze_w_size, gamma, alpha, epsilon, pi, qvc, name, gate, maze,start, original_state_positon):
        AgentParameters.__init__(self, maze_w_size, gamma, alpha, epsilon, pi, qvc)
        EnvParameters.__init__(self, name, gate, maze, start, original_state_positon, qvc)
        # print("testRun ok")


    def episode_Run(self, nepsiode_history):
        print("エピソード")

if __name__ == '__main__':
    print("これは自作モジュールです")
    print("this module is self-mode")

