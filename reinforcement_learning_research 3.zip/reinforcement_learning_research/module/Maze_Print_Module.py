import copy
class Maze_Print:
    def __init__(self,maze):
        self.maze = maze

        self.max_maze = len(self.maze[0])-1
        self.after_erasing = []
        self.after_rotation = []
        self.ar2 = []
        self.Q_maze = []
        self.arrow_list = []

    def maze_print(self):
        for i in self.maze:
            for n in i:
                if n == 1:
                    print(" ■",end="") # colabで動かす時は図形の前に空白はいらない
                elif n == 0:
                    print("  ",end="") #colabで動かすときは空欄ではなく”空”を入れる
                elif n == 3:
                    print(" S",end="")
                elif n == 4 or n == 9:
                    print(" G",end="")
                elif n == 6:
                    print(" △",end="")
                elif n == 7 or n == 9:
                    print("門",end="")
                elif n >= 8:
                    print(f" {str(n-7)}",end="")
                    # print(" T",end="")
                elif n == 2:
                    print(" ▲",end="")
                else:
                    print("他",end="")
            print()

    def Q_maze_print(self):
        for i,n in enumerate(self.arrow_list):
            if (i%11) == 0:
                print()
            if n == 1:
                print(" ■",end="") # colabで動かす時は図形の前に空白はいらない
            elif n == 3:
                print(" S",end="")
            elif n == 4 or n == 9:
                print(" G",end="")
            elif n == 0 or -1 or -2 or -3:
                dire = [" ↑"," →"," ↓"," ←"]
                print(dire[(n+1) * -1 if -4 == n else n*-1],end="")


    def breaking_wall(self):
        # maze_print(maze)
        for i, h in enumerate(self.maze):
            if all(h) == True and h[0] == 1:
                continue
            self.after_erasing.append(h)
        # print()
        # maze_print(after_erasing)

    def rotate(self):
        awd = self.after_erasing   
        # for i in awd:
        #     print(i)
        # print()
        self.after_rotation = [[awd[row][i]for row in range(len(awd))] for i in range(len(awd[0]))]
        # for i in after_rotation:
        #     print(i)

    def wall_destruction(self):
        self.breaking_wall()
        self.rotate()
        self.breaking_wall()
        self.rotate()
        # maze_print(ar2)
        # print(len(ar2)*len(ar2[0]))
        # self.ar2 = ar2

    def make_arrow_list(self, Q, Q_pi_list):
        dire = [0,1,2,3]
        for q, qpl in zip(Q, Q_pi_list):
            if q == []:
                self.arrow_list.append(1)
                continue
            d = dire[q.index(max(q))]
            self.arrow_list.append(qpl[d]*-1)
        





if __name__ == '__main__':
    print("これは自作モジュールです")