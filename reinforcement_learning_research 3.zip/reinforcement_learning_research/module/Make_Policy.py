#方策を作成するクラス・モジュール
import numpy as np
import copy 
class Policy:
    def __init__(self, maze):
        self.maze = maze
        self.after_erasing = 0
        self.after_rotation = 0
        self.wd = 0

    def breaking_wall(self):
        # maze_print(maze)
        after_erasing = []
        for i, h in enumerate(self.maze):
            if all(h) == True and h[0] == 1:
                continue
            after_erasing.append(h)
        # print()
        # maze_print(after_erasing)
        self.after_erasing = after_erasing

    def rotate(self):
        awd = self.after_erasing  
        # for i in awd:
        #     print(i)
        # print()
        after_rotation = [[awd[row][i]for row in range(len(awd))] for i in range(len(awd[0]))]
        # for i in after_rotation:
        #     print(i)
        self.after_rotation = after_rotation


    def wall_destruction(self):
        for i in range(2):
            self.breaking_wall()
            self.rotate()
            self.wd = self.after_rotation

    def upper_judg(self, wh, direction, maze):
        x = [0, len(maze[0])-1, len(maze)-1, 0]
        return 0 if wh == x[direction] else 1

    def test2(self, h, w, dire_x, maze, z):
            if z == 0:
                return np.nan
            dire = [(-1,0),(0,1),(1,0),(0,-1)]
            return 1 if maze[h + dire[dire_x][0]][w + dire[dire_x][1]] == 0 or maze[h + dire[dire_x][0]][w + dire[dire_x][1]] == 3 or maze[h + dire[dire_x][0]][w + dire[dire_x][1]] == 4 else np.nan

    def makeTheta0(self,wd, print_flag = True):
        theta = []
        nan = np.nan
        maze = copy.deepcopy(wd if wd != False else self.wd )
        maze_max = len(maze[0])
        for i, h in enumerate(maze):
            for j, w in enumerate(h):
                if i == len(maze) or j == len(maze[0]):
                    continue
                if maze[i][j] == 1:
                    
                    x = [nan,nan,nan,nan]
                    # print(i,j,x)
                else:
                    z = [self.upper_judg(i,0,maze), self.upper_judg(j,1,maze), self.upper_judg(i,2,maze), self.upper_judg(j,3,maze)]
                    x = [self.test2(i,j,0, maze, z[0]), self.test2(i,j,1, maze, z[1]), self.test2(i,j,2, maze, z[2]), self.test2(i,j,3, maze, z[3])]
                    # print(f"{i},{j}:z = {z} x = {x}")
                if print_flag == True:
                    print(x)
                theta.append(x)
            # print()
        print("方策作成完了")
        return np.array(theta)

if __name__ == '__main__':
    print("これは自作モジュールです")
    print("This module is self-mode")
