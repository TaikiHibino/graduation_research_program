import module.Maze_Print_Module as MP
import module.EnvironmentClass as Env_Class
import module.AgentClass as Agent
import numpy as np

class TestQLearningRun(MP.Maze_Print, Env_Class.MazeEnvironment, Agent.QLearningAgent):
    def __init__(self, maze, name, qvc, Q, maze_w_size, osp):
        super().__init__(maze)
        self.name = name
        self.qvc = qvc
        self.Q = Q
        self.maze_w_size = maze_w_size
        self.osp = osp
        self.S = []
        self.TSS = []
        self.TS_start = 0
        
    
    def run(self, start):
        self.TS_start = start
        self.S, self.TSS = self.condition_standard_converter(self.name, self.TS_start)
        while(1):
            action = np.nanargmax(self.Q[self.TS_start])
            nst, mns, ns = super().next_state(self.TSS, action)
            done = self.goal_judgment(mns)
            if done == True:
                break
            state = nst
            self.TS_start = nst
            self.TSS = ns
            # step += 1
        # print(self.Q)
        # super().maze_print()

if __name__ == '__main__':
    print("これは自作モジュールです")
    print("This module is self-mode")
    