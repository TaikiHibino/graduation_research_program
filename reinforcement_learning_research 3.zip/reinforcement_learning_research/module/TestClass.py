import module.MazeQ_Run as Run
import module.AgentClass as Agent
import module.EnvironmentClass as Env_Class
import numpy as np
import copy

class Test1:
    def __init__(self,x,y):
        self.x = x
        self.y = y
        print(f"x = {self.x}, y = {self.y}")
    
class Test2(Test1):
    def __init__(self, x, y):
        super().__init__(x, y)

#　AgentとEnv_Classを継承している
#　指定回数分エピソードを繰り返すクラス
class Test3(Run.testRun, Agent.QLearningAgent, Env_Class.MazeEnvironment):
    def __init__(self, maze_w_size, gamma, alpha, epsilon, pi, qvc, name, gate, maze,start, original_state_positon):
        super().__init__(maze_w_size, gamma, alpha, epsilon, pi, qvc, name, gate, maze,start, original_state_positon)
        
        self.episode_hitory = [] #各エピソードを格納する
        self.S = []
        self.TSS = []
        self.step_history = []
        self.episode_hitory = []
        self.T_record = {}
        self.start_history = []
        
        self.make_Q_table() # Qテーブルを作成する
        self.action_map = ["↑","→","↓","←"]
        self.check_action = -1
        if len(self.start) <= 1:
            self.Q_table_list.update({self.start[0]:self.Q})
        else:
            for s, ql in zip(self.start,[self.Q] * len(gate)):
                self.Q_table_list.update({s:ql})


    def make_step_record(self):
        [self.T_record.update({i:1000000000}) for i in self.start]
    
    def step_n_record(self, start, step_n):
        if self.T_record[start] > step_n:
            self.T_record[start] = step_n


    def start_decision(self):
        if self.name == "main_maze":
            self.TS_start = self.start[0] if type(self.start) == list and len(self.start) == 1 else self.start
            self.start_history.append(self.TS_start)
            return
        
        self.TS_start = np.random.choice(self.start)
        self.start_history.append(self.TS_start)
        
    def Acsc(self):
        self.S, self.TSS = self.condition_standard_converter(self.name, self.TS_start)

        if self.name == "A"or self.name == "C":
            self.Maze_gate_start = self.S

        elif self.name == "B" or self.name == "D" or self.name == "main_maze":
            self.Maze_gate_start = self.TSS

        # print(f"S:{self.S}, TSS:{self.TSS}, Maze_gate_start{self.S}")

    def reset(self):
        self.start_decision()
        self.Acsc()
        # self.update_maze = super().reset(self.S)

        if self.name == "A" or self.name == "C":
            self.update_maze = super().maze_reset(self.S)

        elif self.name == "B" or self.name == "D" or self.name == "main_maze":
            self.update_maze = super().maze_reset(self.TSS)

    
    def print_color(self, text, color="red"):
        color_dic = {"black":"\033[30m", "red":"\033[31m", "green":"\033[32m", "yellow":"\033[33m", "blue":"\033[34m", "end":"\033[0m"}
        print(color_dic[color] + text + color_dic["end"])
        

    def episode_Run(self, n_epsiode, max_step):
        self.make_step_record()

        print(f"エピソード回数: {n_epsiode}回")
        print(f"最大ステップ数: {max_step}回\n")
        for i in range(n_epsiode):
            
            print(f"-----エピソード{i + 1}回目開始------")
            self.reset()
            print(f"TS_start: {self.TS_start}")
            step = 1
            self.step_history = []

            n = 35 # デフォルト　35
            if (i%n) == 0:   #ε減少率調整　
                self.epsilon /= 2 #エピソードn回に１回　εの確率を割る２減少させる

            while(1):
                if step == max_step + 1:
                    print(f"最大ステップ数{step}回試行")
                    break
                print(f"\nステップ数: {step}回目\n")
                action = super().epsilon_greedy_policy(self.TS_start, self.start_history[-1])
                self.check_action = action
                nst, mns, ns = self.next_state(self.TSS, action)

                if self.name == "A" or self.name == "C":
                    self.update(mns,0)
                elif self.name == "B" or self.name == "D" or self.name == "main_maze":
                    self.update(ns,0)
                
                # reward = self.reward_function(mns)  #デフォルト報酬
                reward = self.reward_manhattan_dead_end_function(mns)
                # reward = self.reward_manhattan_function(mns)
                print(f"\n マンハッタン報酬")

                # if 100 <= i:
                #     reward = self.reward_manhattan_function(mns) #マンハッタン距離報酬関数
                # else:
                #     reward = self.reward_function(mns) #デフォルト報酬関数
                
                print(f" 現状態：{self.TS_start}, 行動: {action} {self.action_map[action]}, 遷移先: {nst}, 報酬: {reward}")
                
                if self.name == "A" or self.name == "C":
                    done = self.goal_judgment(mns)
                elif self.name == "B" or self.name == "D" or self.name == "main_maze":
                    mns = [mns[0]-1,mns[1]-1]
                    done = self.goal_judgment(mns)

                self.update_Q(self.TS_start, nst, action, reward, done, self.start_history[-1]) #Qテーブル更新
                print(done)

                self.step_history.append([self.TS_start,action, nst, reward])

                if done == True:
                    print(f"ゴールをしました\n ステップ数: {step}回")
                    self.step_n_record(self.start_history[-1], step)
                    break
                
                self.TS_start = nst
                self.TSS = ns
                step += 1
            print(f"-----エピソード{i}回目終了------")
            text1 = f"ステップ履歴(状態・行動・次状態・報酬): \n\t {self.step_history}\nステップ総数 {len(self.step_history)}\n"
            # print(f"ステップ履歴(状態・行動・次状態・報酬): \n\t {self.step_history}\nステップ総数 {len(self.step_history)}\n")
            self.print_color(text1,"blue")
            self.episode_hitory.append(self.step_history)
            
            
        line = "-"
        print(f"{line*5}全てのエピソードが終わりました{line*5}")
        # return self.Q, self.episode_hitory, self.T_record
        return self.Q_table_list, self.random_pi, self.episode_hitory, self.T_record
    
if __name__ == '__main__':
    print("これは自作モジュールです")
    print("This module is self-mode")
    

